const UserModel = require("../models/user");
module.exports = {
  register(userObject) {
    let promise = UserModel.create(userObject);
    return promise;
  },
  login() {},
};
