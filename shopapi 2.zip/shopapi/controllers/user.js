const { SUCCESS, SERVER_ERROR } = require("../utils/config").STATUS_CODES;
const messageBundle = require("../locales/en");
const userOperations = require("../db/services/user_crud");
const userController = {
  show(request, response) {
    response.send("U r on Show Section");
  },
  login(request, response) {
    const json = request.body;
    console.log("JSON is ", json);
    response
      .status(SUCCESS)
      .json({ message: messageBundle["login.welcome"], name: json.userid });
    // response.send("U r on Login Section " + JSON.stringify(json));
  },
  register(request, response) {
    // response.send("U r on Register Section");
    let userObject = {
      emailid: request.body.email,
      password: request.body.pwd,
      name: request.body.name,
    };
    const promise = userOperations.register(userObject);
    promise
      .then((doc) => {
        response
          .status(SUCCESS)
          .json({ message: messageBundle["register.welcome"], doc: doc });
      })
      .catch((err) => {
        response
          .status(SERVER_ERROR)
          .json({ message: messageBundle["register.fail"] });
      });
  },
};

module.exports = userController;
