const payments = (request, response) => {
  response.send("Payment Area");
};

module.exports = { payments };
