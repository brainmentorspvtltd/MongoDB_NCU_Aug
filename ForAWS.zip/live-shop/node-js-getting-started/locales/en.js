module.exports = {
  "login.welcome": "Welcome Users",
  "login.invaliduser": "Invalid Userid or Password",
  "register.welcome": "U Register SuccessFully",
  "register.fail": " Register Fail",
  "auth.fail": "UnAuthorized User",
};
