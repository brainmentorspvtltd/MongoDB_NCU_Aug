const fs = require("fs"); // Blocking
// c:\\abcd
const filePath = "/Users/amitsrivastava/Documents/learn-nodejs/basics/one.js"; // Blocking
console.log("I am Here Before readFile Call"); // Block
function done(err, buffer) {
  if (err) {
    console.log("Error During Read ", err);
  } else {
    console.log(buffer.toString());
  }
}
fs.readFile(filePath, done); // Non Blocking
console.log("I am Here After readFile Call"); // Block
