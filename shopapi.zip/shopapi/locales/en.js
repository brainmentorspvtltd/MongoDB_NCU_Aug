module.exports = {
  "login.welcome": "Welcome Users",
  "register.welcome": "U Register SuccessFully",
};
