const { SUCCESS } = require("../utils/config").STATUS_CODES;
const messageBundle = require("../locales/en");
const userController = {
  show(request, response) {
    response.send("U r on Show Section");
  },
  login(request, response) {
    const json = request.body;
    console.log("JSON is ", json);
    response
      .status(SUCCESS)
      .json({ message: messageBundle["login.welcome"], name: json.userid });
    // response.send("U r on Login Section " + JSON.stringify(json));
  },
  register(request, response) {
    // response.send("U r on Register Section");
    response
      .status(SUCCESS)
      .json({ message: messageBundle["register.welcome"] });
  },
};

module.exports = userController;
