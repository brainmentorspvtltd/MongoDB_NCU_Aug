const chalk = require("chalk");
let str = chalk.redBright("Hello Node JS".toUpperCase());
console.log(chalk.bold.underline.bgRed.greenBright("Hi"));
console.log(str);
