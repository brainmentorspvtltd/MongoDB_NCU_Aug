This is a **Calc Package**
Created by _Amit Srivastava_

# Calc App

- Calc Operations Provided
  - add function
  - subtract function
  - mul function
  - divide function
