const calc = require("./index");
console.log(calc.add(10, 20));
console.log(calc.sub(10, 20));
console.log(calc.mul(10, 20));
console.log(calc.divide(10, 20));
