module.exports = {
  add(x, y) {
    return x + y;
  },
  mul(x, y) {
    return x * y;
  },
  divide(x, y) {
    return x / y;
  },
  sub(x, y) {
    return x - y;
  },
};
