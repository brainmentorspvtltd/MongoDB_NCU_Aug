const obj = require("calcbrainmentorsapp");
const result = obj.add(10, 20);
console.log(result);
