process.stdout.write("Enter your Name\n");
let name = "";
process.stdin.on("data", (chunk) => {
  name += chunk;
  process.stdout.write("Your Name is " + name);
});
// process.stdin.on("end", () => {
//   process.stdout.write("Your Name is ", name);
// });
