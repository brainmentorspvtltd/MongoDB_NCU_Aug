function add(x, y) {
  return x + y;
}
let result = add(10, 20);
console.log("Result is ", result);
