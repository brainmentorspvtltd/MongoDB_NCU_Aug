// Command Line Args
const args = process.argv;
//console.log("Args ", args);
//console.log(args[2], args[3]);
let firstNumber = parseInt(args[2]);
let secondNumber = parseInt(args[3]);
console.log(firstNumber + secondNumber);
