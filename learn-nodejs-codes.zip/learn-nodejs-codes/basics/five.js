//const mul2 = require("./four");
// console.log(mul2(10, 20));
//const obj = require("./four");
const { mul } = require("./four"); // Local Module
console.log(mul(10, 5));
// console.log(obj);
// console.log(obj.mul(10, 20));
// console.log(obj.add(10, 20));
// console.log(obj["add"](10, 20));
