console.log("Start"); // Sync
setTimeout(() => {
  // Async
  console.log("I call After 3 sec");
}, 3000); // 1 sec 1000 ms

console.log("End"); // Sync
