const fs = require("fs"); // Node core module
console.log(__dirname); // Current Directory Path
console.log(__filename); // Current File Path
const pathMod = require("path");
//const path = "/Users/amitsrivastava/Documents/learn-nodejs-codes/basics/one.js";
let path = pathMod.join(__dirname, "one.js");
console.log("Before Read");
fs.readFile(path, (err, buffer) => {
  if (err) {
    console.log("Error During File Read ", err);
  } else {
    console.log(buffer.toString());
  }
}); //Async
// "/Users/amitsrivastava/Documents/learn-nodejs-codes/basics/two.js"
path = pathMod.join(__dirname, "two.js");
fs.readFile(path, (err, buffer) => {
  if (err) {
    console.log("Error During File Read ", err);
  } else {
    console.log(buffer.toString());
  }
});
path = pathMod.join(__dirname, "notes.txt");
fs.readFile(path, (err, buffer) => {
  if (err) {
    console.log("Error During File Read ", err);
  } else {
    console.log(buffer.toString());
  }
});
console.log("After Read");
