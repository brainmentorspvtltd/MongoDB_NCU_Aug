// console.log("Hello Node");
// process.stdout.write("Hello Node\n");
const util = require("util");
const printf = function (message) {
  process.stdout.write(message + "\n");
};
printf("hello show");
let mname = "Amit Srivastava";
let result = util.format("My Name is %s ", mname);
//console.log("MY Name is %s ", mname);
console.log(result);
var obj = {
  obj2: [],
  obj3: {
    x: 10,
    obj4: { y: 20, obj5: { h: 100, obj6: { j: 1000, obj7: { yy: 444 } } } },
  },
};
console.log(obj);
//console.dir(obj, { depth: 7 });
console.log(util.inspect(obj, { depth: 7 }));
