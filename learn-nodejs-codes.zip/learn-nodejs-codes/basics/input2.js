const prompt = require("prompt-sync")();
let name = prompt("Enter the Name ");
console.log("Your Name is ", name);
