console.log("Node Current Version ", process.version);
console.log("LibUV Version ", process.versions.uv);
console.log("V8 Version ", process.versions.v8);
process.on("exit", (code) => {
  console.log(`Process Exit ${code}`); // SMS + Email
});
process.on("uncaughtException", (err) => {
  console.log("Error Generated... ", err);
});
f++;
console.log("Cpu arch ", process.arch);
console.log("Platform ", process.platform);
console.log("Login User ", process.env.USER);
console.log("PWD ", process.env.PWD);
