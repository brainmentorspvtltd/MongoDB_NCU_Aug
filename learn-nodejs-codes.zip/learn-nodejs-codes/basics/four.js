// module.exports.mul = function (x, y) {
//   return x * y;
// };

// module.exports.add = function (x, y) {
//   return x + y;
// };

// function mul(x, y) {
//   return x * y;
// }

// function add(x, y) {
//   return x + y;
// }
// module.exports = { mul, add };

// const calc = {
//   add(x, y) {
//     return x + y;
//   },
//   mul() {
//     return x * y;
//   },
// };
// module.exports = calc;

module.exports = {
  add(x, y) {
    return x + y;
  },
  mul(x, y) {
    return x * y;
  },
};
